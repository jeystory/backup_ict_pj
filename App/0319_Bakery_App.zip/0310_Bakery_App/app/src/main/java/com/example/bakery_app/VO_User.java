package com.example.bakery_app;

public class VO_User {
    String user_id;
    String user_pw;
    String user_name;
    String user_addr;

    // 포인트 관련 내용 삭제
    // vo_user - idx(sequance), id(pk), pwd, name, addr,
    // vo_item - item_id(1xx~4xx, pk), item_name, item_price, item_spec, item_allerg
    // vo_order - order_id, user_id, order_div(주무 배송 상태 표시), item_no(no1, no2, no3,,,), order_date.

}
