package com.example.bakery_app;


import android.os.Bundle;
import android.widget.ViewFlipper;

public class HomeActivity extends BaseActivity {
    ViewFlipper viewFlipper;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        viewFlipper = findViewById(R.id.viewFilper);

        viewFlipper.setFlipInterval(2000);
        viewFlipper.startFlipping();
    }
}
