package com.example.bakery_app;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class FragItemSubBase extends Fragment {
    ViewGroup vg ;
    //FragmentManager fragManager;
    Button btn_sub1, btn_sub2, btn_sub3;
    Fragment frag_item_sub01, frag_item_sub02, frag_item_sub03;
    //private OnFragmentInteractionListener mListener;

    public FragItemSubBase() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        vg = (RelativeLayout)inflater.inflate(R.layout.frag_item_sub_base, container, false);

        btn_sub1 = vg.findViewById(R.id.btn_item_sub01);
        btn_sub2 = vg.findViewById(R.id.btn_item_sub02);
        btn_sub3 = vg.findViewById(R.id.btn_item_sub03);

        frag_item_sub01 = new FragItemSub01();
        frag_item_sub02 = new FragItemSub02();
        frag_item_sub03 = new FragItemSub03();

        getFragmentManager().beginTransaction().replace(R.id.layout_sub_item,frag_item_sub01).commit();


        btn_sub1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              getFragmentManager().beginTransaction().replace(R.id.layout_sub_item,frag_item_sub01).commit();
            }
        });

        btn_sub2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getFragmentManager().beginTransaction().replace(R.id.layout_sub_item,frag_item_sub02).commit();
            }
        });

        btn_sub3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.layout_sub_item,frag_item_sub03).commit();
            }
        });

        return vg;
    }
}
