package com.example.bakery_app;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.fragment.app.Fragment;

public class ItemActivity extends BaseActivity {
    Button[] btn_item =new Button[4];
    Fragment[] frag = new Fragment[4];

    Fragment[] item_frag = new Fragment[5];
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        btn_item[0] = findViewById(R.id.btn_cookie);
        btn_item[1] = findViewById(R.id.btn_bread);
        btn_item[2] = findViewById(R.id.btn_dessert);
        btn_item[3] = findViewById(R.id.btn_sandwich);

        frag[0] = new FragItemSubBase();
        frag[1] = new FragUserPoint();

        item_frag[0] = new FragItemCookie();
        item_frag[1] = new FragItemBread();
        item_frag[2] = new FragItemDessert();
        item_frag[3] = new FragItemSandwich();

        //textView.setTextColor(Color.RED); //상수이용
        //content.setTextColor(Color.rgb(red, green, blue)); //RGB메서드 이용
//content.setTextColor(Color.parseColor("#000000")); //색상코드 이용
//출처: https://kkotkkio.tistory.com/21 [KKOTKKIO'S CAVE]
        getSupportFragmentManager().beginTransaction().replace(R.id.item_layout,item_frag[0]).commit();
        btn_item[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //FragItemCookie
                getSupportFragmentManager().beginTransaction().replace(R.id.item_layout,item_frag[0]).commit();
            }
        });

        btn_item[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //FragItemCookie
                getSupportFragmentManager().beginTransaction().replace(R.id.item_layout,item_frag[1]).commit();
            }
        });

        btn_item[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //FragItemCookie
                getSupportFragmentManager().beginTransaction().replace(R.id.item_layout,item_frag[2]).commit();
            }
        });

        btn_item[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //FragItemCookie
                getSupportFragmentManager().beginTransaction().replace(R.id.item_layout,item_frag[3]).commit();
            }
        });

    }


    public void onFragmentChanged(int index){
        if(index == 0){
            getSupportFragmentManager().beginTransaction().replace(R.id.item_layout,frag[0]).commit();
        } else if(index == 1){
            getSupportFragmentManager().beginTransaction().replace(R.id.item_layout,frag[1]).commit();
        }
        else if(index == 2){
            getSupportFragmentManager().beginTransaction().replace(R.id.item_layout,frag[2]).commit();
        }
        else if(index == 3){
            getSupportFragmentManager().beginTransaction().replace(R.id.item_layout,frag[3]).commit();
        }
    }
}