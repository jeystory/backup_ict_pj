package com.example.bakery_app;

public class VO_User {
    String user_id;
    String user_name;
    String user_addr;
    String user_point;

}
