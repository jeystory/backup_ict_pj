package com.example.bakery_app;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class LoginActivity extends BaseActivity{
    Button btn_login, btn_login_join;

    EditText login_id, login_pwd;


    String result;  //db test
    Socket s;       //db test
    Handler handler = new Handler();    //db test
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btn_login = findViewById(R.id.btn_login);
        btn_login_join = findViewById(R.id.btn_login_join);
        login_id = findViewById(R.id.login_id);
        login_pwd = findViewById(R.id.login_pwd);
        //list = findViewById(R.id.list); //db_test

   /*
        btn_login.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                       //String msg_login;
                        result = callServer("10.0.2.2", 7888, "db");
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                //listView에 배열로 저장
                                String[] data = null;
                                try{
                                    data = result.split(",");
                                   if(!data[0].equals("no data")){


                                   } else {
                                       login_id.setText("");
                                       login_pwd.setText("");

                                   }

                                } catch (Exception e){

                                }
                            }
                        });
                    }
                }).start();
            }


        });
         */

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_login = new Intent(LoginActivity.this, UserActivity.class);
                startActivity(intent_login);
                finish();
            }
        });

        btn_login_join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_join = new Intent(LoginActivity.this, JoinActivity.class);
                startActivity(intent_join);
                finish();
            }
        });
    }

    //db_test
    public String callServer(String ip, int port, String msg){
        String str = null;
        BufferedWriter writer = null;
        BufferedReader reader = null;

        try {
            s = new Socket(ip, port);
            writer = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
            reader = new BufferedReader(new InputStreamReader(s.getInputStream()));
            msg = msg+System.getProperty("line.separator");
            writer.write(msg);
            writer.flush();

            str = reader.readLine();

        } catch (Exception e){
            Log.d("my_error", "error 1 "  + e);
        } finally {
            try {
                s.close();
            } catch (Exception e){
                Log.d("my_error", "error 2"  + e);
            }
        }
        return str;
    }
}
