package com.example.bakery_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class JoinActivity extends BaseActivity {
    Button btn_join_fin, btn_join_cancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        btn_join_cancel = findViewById(R.id.btn_join_cancel);
        btn_join_fin = findViewById(R.id.btn_join_fin);

        btn_join_fin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_user = new Intent(JoinActivity.this, UserActivity.class);
                startActivity(intent_user);
                finish();
            }
        });

        btn_join_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home_intent = new Intent(JoinActivity.this, HomeActivity.class);
                startActivity(home_intent);
                finish();
            }
        });
    }
}
