package com.example.bakery_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


public class FragItemList extends Fragment {

    int selectedItem;

    ViewGroup vg ;
    ImageView[] img_item_list = new ImageView[8];
    Integer[] id_img_item = {R.id.img_item_01, R.id.img_item_02, R.id.img_item_03, R.id.img_item_04,
            R.id.img_item_05, R.id.img_item_06, R.id.img_item_07, R.id.img_item_08};
    int[][] imgArr = {{R.drawable.cookie01, R.drawable.cookie02,R.drawable.cookie03, R.drawable.cookie04,
            R.drawable.muffine01, R.drawable.muffine02, R.drawable.muffine03, R.drawable.muffine04},
            {R.drawable.bread01, R.drawable.bread02,R.drawable.bread03, R.drawable.bread04,
            R.drawable.bread05,R.drawable.bread06, R.drawable.bread07, R.drawable.bread08},
            {R.drawable.cake01, R.drawable.cake02,R.drawable.cake03, R.drawable.cake04,
                    R.drawable.cake05,R.drawable.cake06, R.drawable.cake07, R.drawable.cake08},
            {R.drawable.sand01, R.drawable.sand02,R.drawable.sand03, R.drawable.sand04,
                    R.drawable.sand05,R.drawable.sand06, R.drawable.sand07, R.drawable.sand08}

    };
    /*
    int[] imgArrCookie = {R.drawable.cookie01, R.drawable.cookie02,R.drawable.cookie03, R.drawable.cookie04,
            R.drawable.muffine01, R.drawable.muffine02, R.drawable.muffine03, R.drawable.muffine04};
    int[] imgArrBread = {R.drawable.bread01, R.drawable.bread02,R.drawable.bread03, R.drawable.bread04,
            R.drawable.bread05,R.drawable.bread06, R.drawable.bread07, R.drawable.bread08};
    int[] imgArrDessert = {R.drawable.cake01, R.drawable.cake02,R.drawable.cake03, R.drawable.cake04,
            R.drawable.cake05,R.drawable.cake06, R.drawable.cake07, R.drawable.cake08};
    int[] imgArrSand = {R.drawable.sand01, R.drawable.sand02,R.drawable.sand03, R.drawable.sand04,
            R.drawable.sand05,R.drawable.sand06, R.drawable.sand07, R.drawable.sand08};
    */
    FragmentManager fm;
    FragmentTransaction tran;
    FragItemSubBase frag1;
    static ViewGroup viewSub;



    public FragItemList() {
    }

    public FragItemList(int selectedItem) {
        this.selectedItem = selectedItem;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     }

    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //RelativeLayout layout = (RelativeLayout)inflater.inflate(R.layout.frag_item_cookie, container, false);
       vg = (ViewGroup)inflater.inflate(R.layout.frag_item_list,container, false);


        // initialize id of imageview
       for(int i=0;i<8;i++){
           img_item_list[i] = vg.findViewById(id_img_item[i]);
           img_item_list[i].setImageResource(imgArr[selectedItem][i]);
       }






        /*
        ImageView img_cookie_01 =  vg.findViewById(R.id.img_cookie_01);
        //viewSub = container;
        img_cookie_01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             ItemActivity itemActivity = (ItemActivity)getActivity();
             itemActivity.onFragmentChanged(0);

            }
        });
    */
        return vg;
    }



}
