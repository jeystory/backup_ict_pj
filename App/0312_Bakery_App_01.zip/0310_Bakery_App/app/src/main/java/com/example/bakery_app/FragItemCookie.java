package com.example.bakery_app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;


public class FragItemCookie extends Fragment {

    ViewGroup vg ;
    ImageView img_cookie_01;

    FragmentManager fm;
    FragmentTransaction tran;
    FragItemSubBase frag1;
    static ViewGroup viewSub;



    public FragItemCookie() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //RelativeLayout layout = (RelativeLayout)inflater.inflate(R.layout.frag_item_cookie, container, false);
        vg = (ViewGroup)inflater.inflate(R.layout.frag_item_cookie,container, false);

        ImageView img_cookie_01 =  vg.findViewById(R.id.img_cookie_01);
        //viewSub = container;
        img_cookie_01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             ItemActivity itemActivity = (ItemActivity)getActivity();
             itemActivity.onFragmentChanged(0);

            }
        });

        return vg;
    }



}
