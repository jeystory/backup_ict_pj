package com.example.bakery_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ItemSubActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_sub);
    }
}
