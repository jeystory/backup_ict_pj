package com.ict.model;

public class Paging {

}
