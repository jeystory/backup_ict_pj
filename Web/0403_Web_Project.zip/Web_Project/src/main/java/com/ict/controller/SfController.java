package com.ict.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ict.service.CVO;
import com.ict.service.DAO;
import com.ict.service.EVO;
import com.ict.service.IVO;
import com.ict.service.MVO;

@Controller
public class SfController {
	@Autowired
	private DAO dao;
	
	// index 
	@RequestMapping("index.do")
	public ModelAndView indexCommand(@RequestParam("cntPage")String cntPage) {
			/*@RequestParam("cntPage")String cntPage) {*/
		ModelAndView mv = new ModelAndView("index");
		mv.addObject("cntPage", cntPage);
		return mv;
	}
	
	@RequestMapping("home.do")
	public ModelAndView homeCommand() {
				
		ModelAndView mv = new ModelAndView("home");
		
		return mv;
	}
	
	
	
	//notice
	@RequestMapping("main_notice.do")
	public ModelAndView mainNoticeCommand() {
		System.out.println("main_notice.do");
		ModelAndView mv = new ModelAndView("main_notice");
		return mv;
	}
	
	//q&a
	@RequestMapping("item_qa.do")
	public ModelAndView itemQACommand() {
		System.out.println("item_qa.do");
		ModelAndView mv = new ModelAndView("item_qa");
		return mv;
	}
	
	// 나중에 필요없음 지우기
	@RequestMapping("index_cust.do")
	public ModelAndView indexCustCommand() {
		
		ModelAndView mv = new ModelAndView("index_cust");
		return mv;
	}
	
	
	
	
	
	@RequestMapping("item.do")
	public ModelAndView itemSubCommand(@RequestParam("item_category") String item_category,
			HttpSession session) {
		
		ModelAndView mv = new ModelAndView("item");
		List<IVO> itemlist = null;
		try {
			
			itemlist = dao.getItemList(item_category);
		
			//이벤트 정보 가져오기 성공하면
			if(itemlist!= null) {
				session.setAttribute("itemlist", itemlist);
			} else {
				System.out.println("item이 없네");
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		return mv;
	}
	
	
	// 하나의 제품의 상세정보 가져오기
	@RequestMapping("item_sub_detail.do")
	public ModelAndView oneItemDetailCommand(@RequestParam("idx") String idx,
			HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("item_sub_detail");
		
		try {
			IVO ivo = dao.getItemSubDetail(idx);
			mv.addObject("ivo", ivo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return mv;
	}
	
	// insert item
	@RequestMapping(value = "insert_item.do", method = RequestMethod.GET)
	public ModelAndView insertItemCommand_Get(IVO ivo) {
		return new ModelAndView("insert_item_add");
	}
	
	
	@RequestMapping(value = "insert_item.do", method = RequestMethod.POST)
	public ModelAndView insertItemCommand(IVO ivo, 
			HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		
		try {
			
			String path = request.getSession().getServletContext().getRealPath("/resources/images/items");
			MultipartFile file = ivo.getFile();
		
			if (file.isEmpty()) {
				ivo.setFile_name("");
			} else {
				ivo.setFile_name(ivo.getFile().getOriginalFilename());
			}
			
			int result = dao.insertItem(ivo);
			
			if (result > 0) {
				file.transferTo(new File(path + "/" + ivo.getFile_name()));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		//성공하면 
		mv.setViewName("redirect:item.do?item_category=" + ivo.getItem_category());
		return mv;
	}
	
	// 회원관련(Join)
	@RequestMapping("join.do")
	public ModelAndView joinCommand() {
		return new ModelAndView("join");
	}
	
	@RequestMapping("addr_search.do")
	public ModelAndView addrTestCommand() {
		
		ModelAndView mv = new ModelAndView("addr_search");
		return mv;
	}
	
	
	@RequestMapping("join_ok.do")
	public ModelAndView joinOKCommand(MVO mvo,
			HttpSession session) {
		ModelAndView mv = new ModelAndView("home");
		int result = 0;
		try {
			System.out.println("pwd : " + mvo.getPwd());
			result = dao.insertMember(mvo);
			System.out.println("res2 : " + result);
			if(result > 0) {
				session.setAttribute("mvo", mvo);
				session.setAttribute("join", "ok");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("1");
		
		return mv;
	}
	
	@RequestMapping("login.do")
	public ModelAndView loginCommand() {
		return new ModelAndView("login");
	}
	
	@RequestMapping("login_ok.do")
	public ModelAndView login_okCommand(MVO m_vo,
			HttpSession session) {
		ModelAndView mv = new ModelAndView();
		try {
			
			// 로그인 처리
			MVO mvo = dao.getLogin(m_vo);
			
			// 로그인 성공
			if(mvo != null) {
				session.setAttribute("mvo", mvo);
				session.setAttribute("login", "ok");
				// 관리자
				if(mvo.getId().equals("admin") 
					&& mvo.getPwd().equals("1111")) {
					session.setAttribute("admin", "ok");
					//관리자 로그인시 첫화면 - 나중에 변경하기
					mv.setViewName("redirect:admin_item_add.do"); 
					//mv.setViewName("redirect:index_admin.do"); 
					return mv;
				}
				mv.setViewName("redirect:index_cust.do");
			}else {
				mv.setViewName("redirect:login.do");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return mv;
	}
	
	
	
	// 로그 아웃하기
	@RequestMapping("logout.do")
	public ModelAndView logoutCommand(HttpSession session) {
		session.invalidate();
		return new ModelAndView("redirect:index.do");
	}
	
	
	// index_admin.jsp 삭제하면 함께 삭제
	@RequestMapping("index_admin.do")
	public ModelAndView indexAdminCommand() {
		
		ModelAndView mv = new ModelAndView("index_admin");
		return mv;
	}
	
	//  get all of event's information 
	@RequestMapping("event.do")
	public ModelAndView eventCommand(HttpSession session) {
		System.out.println("event.do");
		ModelAndView mv = new ModelAndView("event");
		
		List<EVO> evlist = null;
		
		try {
			
			evlist = dao.getEventList();
						
			//이벤트 정보 가져오기 성공하면
			if(evlist!= null) {
				session.setAttribute("evlist", evlist);
				
			} else {
				System.out.println("이벤트가 없네");
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return mv;
	}
	 	
	// 이벤트 상세 정보 가져오기
	@RequestMapping("event_sub.do")
	public ModelAndView eventSubCommand(
			@RequestParam("idx") String idx, 
			HttpSession session) {
		ModelAndView mv = new ModelAndView();
		
		try {
			System.out.println("idx1 " + idx);
			EVO evo = dao.getSubEvent(idx);
			System.out.println("idx2 " + evo.getIdx());
			
			//이벤트 정보 가져오기 성공하면
			if(evo != null) {
				session.setAttribute("evo", evo);
				mv.setViewName("event_sub");
			} else {
				mv.setViewName("event");
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return mv;
	}
	
	
	// insert item
	@RequestMapping(value = "insert_event.do", method = RequestMethod.GET)
	public ModelAndView insertEventCommand_Get(EVO evo) {
		return new ModelAndView("insert_event");
	}

	@RequestMapping(value = "insert_event.do", method = RequestMethod.POST)
	public ModelAndView insertEventCommand(EVO evo, HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();

		try {

			String path = request.getSession().getServletContext().getRealPath("/resources/images/events");
			MultipartFile lg_file = evo.getSm_file();
			MultipartFile sm_file = evo.getSm_file();

			if (lg_file.isEmpty()) {
				evo.setLg_img("");
			} else {
				evo.setLg_img(evo.getLg_file().getOriginalFilename());
			}

			if (sm_file.isEmpty()) {
				evo.setSm_img("");
			} else {
				evo.setSm_img(evo.getSm_file().getOriginalFilename());
			}

			int result = dao.insertEvent(evo);

			if (result > 0) {
				// sm_file.transferTo(new File(path + "/" + evo.getSm_img()));
				lg_file.transferTo(new File(path + "/" + evo.getLg_img()));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// 성공하면
		mv.setViewName("redirect:event.do");
		return mv;
	}
	
	
	
	// func for admin
	@RequestMapping("admin_order.do")
	public ModelAndView adminOrderCommand() {	
		ModelAndView mv = new ModelAndView("admin_order");
		return mv;
	}
	
	@RequestMapping("admin_review.do")
	public ModelAndView adminReviewCommand() {
		ModelAndView mv = new ModelAndView("admin_review");
		return mv;
	}
	
	
	@RequestMapping("admin_item_qa.do")
	public ModelAndView adminItemQACommand() {
		ModelAndView mv = new ModelAndView("admin_item_qa");
		return mv;
	}
	
	@RequestMapping("admin_item_add.do")
	public ModelAndView adminItemAddCommand() {
		ModelAndView mv = new ModelAndView("admin_item_add");
		return mv;
	}
	
	@RequestMapping("admin_event_add.do")
	public ModelAndView adminEventAddCommand() {
		ModelAndView mv = new ModelAndView("admin_event_add");
		return mv;
	}
	
	// Cart
	@RequestMapping("cart_list.do")
	public ModelAndView cartListCommand(
			@RequestParam("cust_id") String cust_id) {
		ModelAndView mv = new ModelAndView("cart_list");
		try {
			List<CVO> cart_list = dao.getCartList(cust_id);
			mv.addObject("cart_list", cart_list);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mv;
	}
	
	@RequestMapping("edit_cart_amt.do")
	public ModelAndView editeCountCommand(CVO cvo) {
		try {
			dao.getCartEdit(cvo);
		} catch (Exception e) {
			System.out.println(e);
		}
		return new ModelAndView("redirect:cart_list.do?cust_id="+cvo.getCust_id());
	}
	
	@RequestMapping("add_cart.do")
	public ModelAndView addCartCommand(
			@RequestParam("cust_id") String cust_id,
			@RequestParam("idx") String idx) {
		ModelAndView mv = new ModelAndView("redirect:cart_list.do?cust_id="+ cust_id);
				
		try {
			// idx를 이용해서 제품 정보 가져오기 
			IVO ivo = dao.getItemSubDetail(idx);
						
			// id와 제품번호를 가지고 카드 정보 가져오기 
			CVO cvo = dao.getCartItem(cust_id, idx);
			
			// 해당 제품이 카드정보 존재 유무를 확인
			// 존재하면 갯수만 증가, 존재하지 않으면 해당 제품을 카트 정보 추가
			if(cvo == null) {
			// 카트에 제품이 없으므로 카트에 추가 
				 CVO c_vo = new CVO();
				 c_vo.setItem_id(idx);
				 c_vo.setItem_price(String.valueOf(ivo.getItem_price()));
				 c_vo.setItem_name(ivo.getItem_name());
				 c_vo.setCust_id(cust_id);
				 dao.insertCart(c_vo);
			}else {
			// 카트에 제품이 있으므로 제품의 갯수를 1증가 시킨다.
				dao.updateCart(cvo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mv ;
		
	}
	
	@RequestMapping("delete_cart.do")
	public ModelAndView deleteCartCommand(CVO cvo) {
		ModelAndView mv = new ModelAndView("redirect:cart_list.do?cust_id="+ cvo.getCust_id());
		int result = 0;
		
		try {
			System.out.println("cust_id : " + cvo.getCust_id());
			System.out.println("item_id : " + cvo.getItem_id());
			result = dao.deleteCart(cvo);
		} catch (Exception e) {
			System.out.println("3");
			e.printStackTrace();
		}
		
		System.out.println("result : " + result);
		return mv;
	}
}
