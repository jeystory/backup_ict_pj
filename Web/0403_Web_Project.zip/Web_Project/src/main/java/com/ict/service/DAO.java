package com.ict.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

public class DAO {
	private SqlSessionTemplate sqlSessionTemplate;
	private DataSourceTransactionManager transactionManager ;

	public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
		this.sqlSessionTemplate = sqlSessionTemplate;
	}
	public void setTransactionManager(DataSourceTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}
	
	
	
	//get item info
	public List<IVO> getItemList(String item_category) throws Exception{
		return sqlSessionTemplate.selectList("get_item_list", item_category);
	}
	
	public IVO getItemSubDetail(String idx) throws Exception{
		IVO ivo = new IVO();
		
		ivo = sqlSessionTemplate.selectOne("item_sub_detail", idx);
		return ivo;
	}
	
	public int insertItem(IVO ivo) {
		int result = 0;
		
		result = sqlSessionTemplate.insert("insert_item", ivo);
				
		return result;
	}
	
	
	
	public MVO getLogin(MVO mvo) throws Exception{
		System.out.println(mvo.getId());
		return sqlSessionTemplate.selectOne("login", mvo);
	}
	
	//Event Info
	public List<EVO> getEventList() throws Exception {	
		return sqlSessionTemplate.selectList("get_event_list");
	}
	
		
	public EVO getSubEvent(String idx) throws Exception{
		System.out.println("dao idx " + idx);
		return sqlSessionTemplate.selectOne("get_sub_event", idx);
	}
	
	public int insertEvent(EVO evo) throws Exception{
		int result = 0;
		
		result = sqlSessionTemplate.insert("insert_event", evo);
		
		return result;
	}
	
	public List<CVO> getCartList(String cust_id) throws Exception{
		List<CVO> list = sqlSessionTemplate.selectList("get_cart_list", cust_id);
		return list;
	}
	
	public void getCartEdit(CVO cvo) throws Exception{
		sqlSessionTemplate.update("cart_edit", cvo);
	}
	
	public CVO getCartItem(String cust_id, String item_id)   throws Exception{
		CVO cvo = null;
		Map< String, String> map = new HashMap<String, String>();
		
		map.put("cust_id",cust_id);
		map.put("item_id",item_id);
		cvo  = sqlSessionTemplate.selectOne("get_cart_item", map);
		return cvo;
		
		
	}
	
	public void insertCart(CVO cvo)throws Exception{
		
		sqlSessionTemplate.insert("cart_insert", cvo);
	}

	public void updateCart(CVO cvo) throws Exception{
		sqlSessionTemplate.update("cart_update", cvo);
	}
	
	public int deleteCart(CVO cvo) throws Exception{
		int result = sqlSessionTemplate.delete("cart_delete", cvo);
		return result;
	}
	
	
	//join member
	public int insertMember(MVO mvo) throws Exception{
		return sqlSessionTemplate.insert("member_insert", mvo);
	}
	
		
}
